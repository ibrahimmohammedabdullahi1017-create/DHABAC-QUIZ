
import React, { useState, useEffect } from 'react';
import { AppState, User, QuizResult, Question, QuizCategory } from './types';
import { INITIAL_QUESTIONS, QUIZ_CONFIG } from './constants';
import Dashboard from './components/Dashboard';
import QuizContainer from './components/QuizContainer';
import Results from './components/Results';
import Admin from './components/Admin';
import AdminLogin from './components/AdminLogin';
import LandingPage from './components/LandingPage';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(AppState.LANDING);
  const [user, setUser] = useState<User | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<QuizCategory>('general');
  const [questions, setQuestions] = useState<Question[]>(() => {
    const saved = localStorage.getItem('quiz_questions');
    return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
  });
  const [globalQuizCategory, setGlobalQuizCategory] = useState<QuizCategory>(() => {
    return (localStorage.getItem('quiz_category') as QuizCategory) || 'private';
  });
  const [result, setResult] = useState<QuizResult | null>(null);
  const [isAlreadyRunning, setIsAlreadyRunning] = useState(false);

  // Persistence for Admin session
  useEffect(() => {
    const isAdminAuthenticated = sessionStorage.getItem('admin_authenticated') === 'true';
    if (isAdminAuthenticated && state === AppState.LANDING) {
      // Session is preserved
    }
  }, [state]);

  useEffect(() => {
    const checkSession = () => {
      const active = sessionStorage.getItem('quiz_active');
      if (active === 'true' && state !== AppState.TAKING && state !== AppState.COMPLETED) {
        setIsAlreadyRunning(true);
      }
    };
    checkSession();
  }, [state]);

  const handleStartQuiz = (userData: User, category: QuizCategory) => {
    setUser(userData);
    setSelectedCategory(category);
    setState(AppState.TAKING);
    sessionStorage.setItem('quiz_active', 'true');
  };

  const handleQuizFinish = (results: QuizResult) => {
    // Save to global submissions for teacher access
    const existingSubmissionsStr = localStorage.getItem('quiz_submissions');
    const existingSubmissions: QuizResult[] = existingSubmissionsStr ? JSON.parse(existingSubmissionsStr) : [];
    localStorage.setItem('quiz_submissions', JSON.stringify([...existingSubmissions, results]));

    setResult(results);
    setState(AppState.COMPLETED);
    sessionStorage.removeItem('quiz_active');
  };

  const handleReset = () => {
    setState(AppState.LANDING);
    setUser(null);
    setResult(null);
  };

  const handleAdminAuthSuccess = () => {
    sessionStorage.setItem('admin_authenticated', 'true');
    setState(AppState.ADMIN);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('admin_authenticated');
    handleReset();
  };

  // Filter questions based on the student's chosen category
  const filteredQuestions = questions.filter(q => q.category === selectedCategory);

  if (isAlreadyRunning) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
        <div className="bg-white p-12 rounded-[3rem] shadow-2xl max-w-md w-full text-center border-t-8 border-red-600">
          <div className="text-red-600 mb-8 flex justify-center">
             <div className="bg-red-50 p-6 rounded-3xl animate-bounce">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
             </div>
          </div>
          <h1 className="text-3xl font-black text-slate-800 mb-4 uppercase tracking-tighter">AL-BAABKU WAA UXIRAN YAHAY</h1>
          <p className="text-slate-500 mb-10 font-medium leading-relaxed">
            Nidaamka amnigu wuxuu ogaaday in imtixaanku meel kale ka furan yahay. Fadlan xir tab-yada kale si aad u sii wadato.
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg hover:bg-slate-800 shadow-2xl shadow-slate-200 transition-all active:scale-95"
          >
            Cusboonaysii Bogga
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 selection:bg-blue-100 flex flex-col">
      <header className="bg-white/80 backdrop-blur-xl border-b sticky top-0 z-50 transition-all border-slate-100">
        <div className="max-w-6xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-4 cursor-pointer group" onClick={handleReset}>
            {/* Displaying the Academy Logo in a professional circular frame */}
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl shadow-blue-100 transition-transform group-hover:scale-110 overflow-hidden border-2 border-slate-50 p-0.5">
              <img 
                src="https://raw.githubusercontent.com/username/repo/main/logo.png" 
                alt="Alnaciim Educational Academy Logo" 
                className="w-full h-full object-cover rounded-full"
                onError={(e) => {
                  // If image is missing, we use a high-quality SVG fallback that mimics the seal
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent) {
                    parent.innerHTML = `
                      <div class="w-full h-full bg-gradient-to-br from-blue-700 to-indigo-900 flex items-center justify-center p-2 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                        </svg>
                      </div>
                    `;
                  }
                }}
              />
            </div>
            <div className="flex flex-col">
              <h1 className="text-2xl md:text-3xl font-black tracking-tighter bg-gradient-to-r from-blue-700 to-indigo-800 bg-clip-text text-transparent uppercase">
                Dhabac Quiz
              </h1>
              <span className="text-[8px] md:text-[9px] uppercase tracking-[0.1em] md:tracking-[0.2em] font-black text-indigo-500/80 -mt-1 pl-1">
                Platform Alnaciim Educational Academy
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {state === AppState.ADMIN && (
              <button 
                onClick={handleLogout}
                className="text-[10px] font-black uppercase tracking-widest text-red-500 hover:bg-red-50 px-4 py-2 rounded-xl transition-all border border-transparent hover:border-red-100"
              >
                Logout
              </button>
            )}
            {state !== AppState.LANDING && state !== AppState.TAKING && (
              <button 
                onClick={handleReset}
                className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-600 transition-all flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-xl border border-slate-100"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                Home
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-10 w-full flex-1">
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
          {state === AppState.LANDING && (
            <LandingPage 
              onSelectStudent={() => setState(AppState.IDLE)} 
              onSelectTeacher={() => {
                const isAuth = sessionStorage.getItem('admin_authenticated') === 'true';
                setState(isAuth ? AppState.ADMIN : AppState.ADMIN_AUTH);
              }} 
            />
          )}
          {state === AppState.IDLE && (
            <Dashboard 
              onStart={handleStartQuiz} 
              questionsCount={questions.length} 
              timeLimit={QUIZ_CONFIG.timeLimitSeconds} 
              quizTitle={QUIZ_CONFIG.title}
              quizCategory={globalQuizCategory}
            />
          )}
          {state === AppState.ADMIN_AUTH && (
            <AdminLogin 
              onSuccess={handleAdminAuthSuccess} 
              onCancel={handleReset} 
            />
          )}
          {state === AppState.TAKING && user && (
            <QuizContainer 
              user={user} 
              questions={filteredQuestions} 
              onFinish={handleQuizFinish} 
              timeLimit={QUIZ_CONFIG.timeLimitSeconds}
              category={selectedCategory}
            />
          )}
          {state === AppState.COMPLETED && result && (
            <Results 
              result={result} 
              onRestart={handleReset} 
            />
          )}
          {state === AppState.ADMIN && (
            <Admin 
              questions={questions} 
              onUpdateQuestions={(q) => {
                setQuestions(q);
                localStorage.setItem('quiz_questions', JSON.stringify(q));
              }}
              onCategoryChange={(cat) => {
                setGlobalQuizCategory(cat);
                localStorage.setItem('quiz_category', cat);
              }}
              currentCategory={globalQuizCategory}
              onBack={handleReset}
            />
          )}
        </div>
      </main>

      <footer className="py-10 text-center border-t bg-white border-slate-100">
        <div className="max-w-6xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-col items-center md:items-start">
            <p className="text-slate-800 text-sm font-black tracking-wider uppercase">ALNACIIM DEGITAL EDUCATION</p>
            <p className="text-slate-400 text-[10px] font-medium uppercase tracking-widest">Powered by SecureQuiz Engine v2.0</p>
          </div>
          <div className="flex gap-6">
             <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-600 rounded-lg text-[9px] font-black uppercase border border-green-100">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                Encrypted Connection
             </div>
             <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-[9px] font-black uppercase border border-blue-100">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                Secure Access
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
