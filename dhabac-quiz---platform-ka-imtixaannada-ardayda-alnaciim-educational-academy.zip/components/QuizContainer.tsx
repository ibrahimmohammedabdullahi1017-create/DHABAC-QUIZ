
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { User, Question, QuizResult, QuizCategory } from '../types';

interface QuizContainerProps {
  user: User;
  questions: Question[];
  onFinish: (result: QuizResult) => void;
  timeLimit: number;
  category: QuizCategory;
}

const QuizContainer: React.FC<QuizContainerProps> = ({ user, questions, onFinish, timeLimit, category }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(timeLimit);
  const [isFinishing, setIsFinishing] = useState(false);
  const [warnings, setWarnings] = useState(0);
  const [showWarning, setShowWarning] = useState(false);

  const currentQuestion = questions[currentIndex];
  const progress = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0;
  const isAnswered = !!answers[currentQuestion?.id];

  const calculateResult = useCallback((): QuizResult => {
    let correct = 0;
    questions.forEach((q) => {
      if (answers[q.id] === q.correctAnswer) {
        correct++;
      }
    });

    return {
      totalQuestions: questions.length,
      correctAnswers: correct,
      wrongAnswers: questions.length - correct,
      percentage: questions.length > 0 ? (correct / questions.length) * 100 : 0,
      timestamp: new Date().toISOString(),
      user,
      userAnswers: answers,
      questions: [...questions],
      category
    };
  }, [answers, questions, user, category]);

  const finishQuiz = useCallback(() => {
    if (isFinishing) return;
    setIsFinishing(true);
    onFinish(calculateResult());
  }, [calculateResult, onFinish, isFinishing]);

  // Security: Prevent Right-Click and Copy
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'c' || e.key === 'v' || e.key === 'u')) {
        e.preventDefault();
      }
    };

    // Security: Tab switch detection
    const handleVisibilityChange = () => {
      if (document.hidden) {
        setWarnings(prev => {
          const newCount = prev + 1;
          if (newCount >= 3) {
            finishQuiz(); // Auto-submit if too many warnings
          } else {
            setShowWarning(true);
          }
          return newCount;
        });
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [finishQuiz]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          finishQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [finishQuiz]);

  const handleSelectAnswer = (answer: string) => {
    if (!currentQuestion || isAnswered) return;
    setAnswers(prev => ({ ...prev, [currentQuestion.id]: answer }));
  };

  const renderMedia = () => {
    if (!currentQuestion || !currentQuestion.mediaUrl) return null;

    if (currentQuestion.mediaType === 'image') {
      return (
        <div className="mb-6 rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
          <img 
            src={currentQuestion.mediaUrl} 
            alt="Question Media" 
            className="w-full h-auto max-h-[300px] object-contain bg-slate-50 select-none pointer-events-none"
          />
        </div>
      );
    }

    if (currentQuestion.mediaType === 'video') {
      return (
        <div className="mb-6 rounded-2xl overflow-hidden border border-slate-100 shadow-sm aspect-video bg-black">
          <iframe 
            src={currentQuestion.mediaUrl.includes('youtube') ? currentQuestion.mediaUrl.replace('watch?v=', 'embed/') : currentQuestion.mediaUrl}
            title="Question Video"
            className="w-full h-full"
            allowFullScreen
          ></iframe>
        </div>
      );
    }

    return null;
  };

  if (!currentQuestion) {
    return (
      <div className="max-w-3xl mx-auto p-12 bg-white rounded-3xl text-center">
        <h3 className="text-2xl font-black text-slate-800 mb-4">Ma jiraan su'aalo halkan!</h3>
        <p className="text-slate-500 mb-8">Nidaamka ma helin wax su'aalo ah oo ku jira qaybta aad dooratay.</p>
        <button onClick={() => finishQuiz()} className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-bold">Ka bax</button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 select-none">
      {/* Anti-cheat Warnings */}
      {showWarning && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/90 backdrop-blur-sm p-4 animate-in fade-in zoom-in">
          <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl max-w-md w-full text-center border-4 border-red-500">
             <div className="w-20 h-20 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
             </div>
             <h2 className="text-3xl font-black text-slate-800 mb-4 uppercase">DIGNIIN QISH!</h2>
             <p className="text-slate-500 font-bold mb-8">
               Ha beddelin Tab-ka ama Browser-ka. Digniinta {warnings}/3. Haddii aad saddex gaarto imtixaanku iskiis ayuu u xirmayaa.
             </p>
             <button 
               onClick={() => setShowWarning(false)}
               className="w-full py-4 bg-red-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-red-200"
             >
               Waan Fahmay
             </button>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-black">
            {currentIndex + 1}
          </div>
          <div className="flex flex-col">
             <span className="font-black text-slate-800 text-sm leading-tight">{user.name}</span>
             <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
                <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest">SECURE SESSION</span>
             </div>
          </div>
        </div>
        <div className={`px-5 py-2.5 rounded-2xl font-mono font-black text-xl flex items-center gap-2 ${timeLeft < 60 ? 'bg-red-50 text-red-600 animate-pulse' : 'bg-slate-900 text-white'}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-xl p-8 md:p-12 border border-slate-100 min-h-[400px] relative overflow-hidden">
        {/* Subtle security watermark */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] rotate-[-25deg] flex items-center justify-center flex-wrap gap-20 overflow-hidden">
          {Array(20).fill(0).map((_, i) => <span key={i} className="text-slate-900 font-black text-6xl">{user.studentId}</span>)}
        </div>

        <div className="relative z-10">
          {renderMedia()}
          <h3 className="text-2xl md:text-3xl font-black text-slate-800 mb-10 leading-snug">
            {currentQuestion.text}
          </h3>

          <div className="grid gap-4">
            {currentQuestion.type === 'multiple-choice' ? (
              currentQuestion.options?.map((option, idx) => (
                <button
                  key={idx}
                  disabled={isAnswered}
                  onClick={() => handleSelectAnswer(option)}
                  className={`p-6 rounded-[1.5rem] border-2 text-left transition-all flex items-center gap-5 ${
                    answers[currentQuestion.id] === option 
                    ? 'border-blue-600 bg-blue-50 text-blue-900 ring-4 ring-blue-100' 
                    : isAnswered ? 'opacity-50 cursor-not-allowed border-slate-100' : 'border-slate-50 hover:bg-slate-50 hover:border-slate-200'
                  }`}
                >
                  <span className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg ${answers[currentQuestion.id] === option ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-white border-2 text-slate-400'}`}>
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="font-bold text-lg">{option}</span>
                </button>
              ))
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {['Run', 'Been'].map((option) => (
                  <button
                    key={option}
                    disabled={isAnswered}
                    onClick={() => handleSelectAnswer(option)}
                    className={`p-8 rounded-[2rem] border-2 font-black text-2xl transition-all ${
                      answers[currentQuestion.id] === option 
                      ? 'border-blue-600 bg-blue-50 text-blue-900 ring-4 ring-blue-100' 
                      : isAnswered ? 'opacity-50 border-slate-100' : 'border-slate-50 hover:bg-slate-50 hover:border-slate-200'
                    }`}
                  >
                    {option}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="mt-12 flex gap-4">
            <button 
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex(prev => prev - 1)}
              className="px-8 py-5 bg-slate-100 text-slate-500 rounded-2xl font-black hover:bg-slate-200 disabled:opacity-30 transition-all uppercase tracking-widest text-xs"
            >
              Hore
            </button>
            <button 
              onClick={() => currentIndex === questions.length - 1 ? finishQuiz() : setCurrentIndex(prev => prev + 1)}
              className="flex-1 py-5 bg-blue-600 text-white rounded-2xl font-black text-lg shadow-xl shadow-blue-100 hover:bg-blue-700 transition-all uppercase tracking-widest"
            >
              {currentIndex === questions.length - 1 ? 'Dhameey Imtixaanka' : 'Su\'aasha Xigta'}
            </button>
          </div>
        </div>
      </div>
      
      <div className="space-y-2">
        <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 px-2">
          <span>Horumarkaaga</span>
          <span>{Math.round(progress)}% Complete</span>
        </div>
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200 p-0.5">
          <div className="h-full bg-blue-600 rounded-full transition-all duration-500 ease-out shadow-[0_0_10px_rgba(37,99,235,0.4)]" style={{ width: `${progress}%` }}></div>
        </div>
      </div>
    </div>
  );
};

export default QuizContainer;
