
import React from 'react';

interface LandingPageProps {
  onSelectStudent: () => void;
  onSelectTeacher: () => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onSelectStudent, onSelectTeacher }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16">
      <div className="text-center mb-16 space-y-6">
        <div className="inline-block px-6 py-2 bg-blue-600 rounded-2xl text-[11px] font-black uppercase tracking-[0.4em] text-white shadow-lg shadow-blue-200 mb-2 animate-bounce">
          SOO DHAWAADA (WELCOME)
        </div>
        <h2 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-none uppercase">
          KUSOO DHAWAAW <span className="text-blue-600 block md:inline">DHABAC QUIZ</span>
        </h2>
        <div className="w-24 h-2 bg-blue-600 mx-auto rounded-full mb-6"></div>
        <p className="text-slate-500 font-bold text-lg md:text-xl max-w-2xl mx-auto leading-relaxed italic">
          "Waxaan kugu soo dhawaynayaa Platform ka <span className="text-slate-800 font-black">ALNACIIM</span> ee <span className="text-blue-600 font-black">DHABAC QUIZ</span>"
        </p>
        <p className="text-slate-400 font-medium text-sm">Fadlan dooro marinkaaga si aad u sii wadato adeegga.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
        {/* Student Card */}
        <button 
          onClick={onSelectStudent}
          className="group relative bg-white p-12 rounded-[4rem] border-2 border-slate-50 hover:border-blue-500 transition-all shadow-2xl shadow-slate-200/50 text-left overflow-hidden flex flex-col items-start transform hover:-translate-y-2 duration-500"
        >
          <div className="w-24 h-24 bg-blue-50 rounded-[2rem] flex items-center justify-center text-blue-600 mb-10 group-hover:bg-blue-600 group-hover:text-white transition-all duration-700 shadow-inner">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" />
            </svg>
          </div>
          <h3 className="text-4xl font-black text-slate-900 mb-4 uppercase tracking-tighter">Marinka Ardayga</h3>
          <p className="text-slate-400 font-bold text-sm mb-10 leading-relaxed">
            Halkaan ka gal imtixaannada adiga oo isticmaalaya ID-gaaga gaarka ah iyo Quiz Code-ka (Haddii loo baahdo).
          </p>
          <div className="mt-auto flex items-center gap-3 text-blue-600 font-black text-xs uppercase tracking-[0.2em] group-hover:translate-x-4 transition-transform duration-500">
            Gal Dashboard-ka
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </div>
          {/* Decorative element */}
          <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-blue-50 rounded-full opacity-50 group-hover:scale-150 transition-transform duration-1000"></div>
        </button>

        {/* Teacher Card */}
        <button 
          onClick={onSelectTeacher}
          className="group relative bg-slate-900 p-12 rounded-[4rem] border-2 border-slate-800 hover:border-indigo-500 transition-all shadow-2xl text-left overflow-hidden flex flex-col items-start transform hover:-translate-y-2 duration-500"
        >
          <div className="w-24 h-24 bg-indigo-500/10 rounded-[2rem] flex items-center justify-center text-indigo-400 mb-10 group-hover:bg-indigo-500 group-hover:text-white transition-all duration-700 shadow-inner">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h3 className="text-4xl font-black text-white mb-4 uppercase tracking-tighter">Marinka Macallinka</h3>
          <p className="text-slate-400 font-bold text-sm mb-10 leading-relaxed">
            Maamul su'aalaha, kormeer natiijooyinka, oo deji habka amniga iyo gelitaanka imtixaanka.
          </p>
          <div className="mt-auto flex items-center gap-3 text-indigo-400 font-black text-xs uppercase tracking-[0.2em] group-hover:translate-x-4 transition-transform duration-500">
            Soo gal Maamulka
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </div>
          {/* Decorative element */}
          <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-indigo-500/10 rounded-full opacity-10 group-hover:scale-150 transition-transform duration-1000"></div>
        </button>
      </div>
      
      <div className="mt-24 flex flex-col items-center">
        <div className="bg-white/80 backdrop-blur-md px-10 py-6 rounded-[2rem] flex items-center gap-8 text-slate-400 font-black text-[10px] uppercase tracking-[0.25em] border border-slate-100 shadow-xl shadow-slate-100">
          <span className="flex items-center gap-2"><span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span> SYSTEM ONLINE</span>
          <span className="w-px h-6 bg-slate-200"></span>
          <span className="flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
            SECURITY: HIGH
          </span>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
