
import React, { useState } from 'react';
import { QuizResult } from '../types';

interface ResultsProps {
  result: QuizResult;
  onRestart: () => void;
}

const Results: React.FC<ResultsProps> = ({ result, onRestart }) => {
  const [localResult, setLocalResult] = useState<QuizResult>(result);
  const [message, setMessage] = useState(result.studentMessage || '');
  const [isSaved, setIsSaved] = useState(false);
  
  const isPassed = localResult.percentage >= 70;

  const handleSaveMessage = () => {
    // Update local state
    setLocalResult(prev => ({ ...prev, studentMessage: message }));
    
    // Update saved submissions in localStorage so teacher sees the message
    const submissionsStr = localStorage.getItem('quiz_submissions');
    if (submissionsStr) {
      const submissions: QuizResult[] = JSON.parse(submissionsStr);
      const updated = submissions.map(s => 
        (s.timestamp === result.timestamp && s.user.studentId === result.user.studentId) 
        ? { ...s, studentMessage: message } 
        : s
      );
      localStorage.setItem('quiz_submissions', JSON.stringify(updated));
    }

    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-12">
      {/* Header Summary */}
      <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100">
        <div className={`p-12 text-center text-white ${isPassed ? 'bg-green-600' : 'bg-red-500'}`}>
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-sm">
            {isPassed ? (
               <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
              </svg>
            )}
          </div>
          <h2 className="text-3xl font-bold mb-2">
            {isPassed ? 'Hambalyo! Waad Baastay' : 'Isku day kale! Ma aadan Gudbin'}
          </h2>
          <p className="text-white/80">
            Natiijadaadu waa mid diyaar ah. Hoosta ka eeg faahfaahinta.
          </p>
        </div>

        <div className="p-10">
          <div className="flex justify-center -mt-20 mb-10">
            <div className="bg-white p-6 rounded-2xl shadow-xl flex items-center justify-center flex-col min-w-[180px]">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Natiijada Guud</p>
              <p className={`text-5xl font-black ${isPassed ? 'text-green-600' : 'text-red-600'}`}>
                {Math.round(localResult.percentage)}%
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6 mb-10">
            <div className="text-center p-4 bg-slate-50 rounded-2xl border border-slate-100">
              <p className="text-xs font-bold text-slate-400 mb-1 uppercase">Su'aalo</p>
              <p className="text-2xl font-bold text-slate-800">{localResult.totalQuestions}</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-2xl border border-green-100">
              <p className="text-xs font-bold text-green-500 mb-1 uppercase">Sax</p>
              <p className="text-2xl font-bold text-green-700">{localResult.correctAnswers}</p>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-2xl border border-red-100">
              <p className="text-xs font-bold text-red-500 mb-1 uppercase">Qalad</p>
              <p className="text-2xl font-bold text-red-700">{localResult.wrongAnswers}</p>
            </div>
          </div>

          {/* Teacher Message Section */}
          <div className="mb-10 p-6 bg-blue-50/50 rounded-3xl border border-blue-100/50">
            <h4 className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M2 5a2 2 0 012-2h7a2 2 0 012 2v4a2 2 0 01-2 2H9l-3 3v-3H4a2 2 0 01-2-2V5z" />
                <path d="M15 7v2a4 4 0 01-4 4H9.828l-1.766 1.767c.28.149.599.233.938.233h2l3 3v-3h2a2 2 0 002-2V9a2 2 0 00-2-2h-1z" />
              </svg>
              Farriin u reeb Macalinka
            </h4>
            <div className="space-y-4">
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Halkan ku qor haddii aad hayso su'aal ama faallo..."
                className="w-full p-4 bg-white border border-blue-100 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-400 outline-none transition-all font-medium text-slate-700 placeholder:text-slate-300 min-h-[100px]"
              />
              <button
                onClick={handleSaveMessage}
                disabled={!message.trim()}
                className={`w-full py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2 ${
                  isSaved 
                  ? 'bg-green-500 text-white' 
                  : 'bg-blue-600 text-white hover:bg-blue-700 disabled:bg-blue-200 disabled:cursor-not-allowed'
                }`}
              >
                {isSaved ? (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    Waa la keydiyay!
                  </>
                ) : 'Keydi Farriinta'}
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={onRestart}
              className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition shadow-lg shadow-slate-200"
            >
              Ka Bax (Home)
            </button>
          </div>
        </div>
      </div>

      {/* Detailed Review Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <div className="h-px bg-slate-200 flex-1"></div>
          <h3 className="text-lg font-bold text-slate-400 uppercase tracking-widest">Dib u eegis Su'aalaha</h3>
          <div className="h-px bg-slate-200 flex-1"></div>
        </div>

        {localResult.questions.map((q, index) => {
          const userAnswer = localResult.userAnswers[q.id];
          const isCorrect = userAnswer === q.correctAnswer;
          
          return (
            <div 
              key={q.id} 
              className={`bg-white rounded-2xl p-6 border-l-8 shadow-sm transition-all ${
                isCorrect ? 'border-green-500' : 'border-red-500'
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <span className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-white ${
                    isCorrect ? 'bg-green-500' : 'bg-red-500'
                  }`}>
                    {index + 1}
                  </span>
                  <span className={`text-xs font-black uppercase tracking-tighter ${
                    isCorrect ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {isCorrect ? 'Sax' : 'Qalad'}
                  </span>
                </div>
                {isCorrect ? (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ) : (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )}
              </div>

              <h4 className="text-lg font-bold text-slate-800 mb-6">{q.text}</h4>

              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <span className="text-sm font-semibold text-slate-400 w-32">Jawaabtaada:</span>
                  <div className={`px-4 py-2 rounded-xl font-medium text-sm inline-block ${
                    isCorrect ? 'bg-green-50 text-green-700 border border-green-100' : 'bg-red-50 text-red-700 border border-red-100'
                  }`}>
                    {userAnswer || '(Ma jiro)'}
                  </div>
                </div>
                
                {!isCorrect && (
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="text-sm font-semibold text-slate-400 w-32">Jawaabta Saxda ah:</span>
                    <div className="px-4 py-2 rounded-xl bg-green-50 text-green-700 border border-green-100 font-bold text-sm inline-block">
                      {q.correctAnswer}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Results;
