
import React, { useState } from 'react';
import { User, QuizCategory } from '../types';

interface DashboardProps {
  onStart: (user: User, category: QuizCategory) => void;
  questionsCount: number;
  timeLimit: number;
  quizTitle: string;
  quizCategory: QuizCategory;
}

const Dashboard: React.FC<DashboardProps> = ({ onStart, questionsCount, timeLimit, quizTitle, quizCategory }) => {
  const [activeTab, setActiveTab] = useState<QuizCategory>('general');
  const [name, setName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [quizCode, setQuizCode] = useState('');
  const [error, setError] = useState('');

  const validateStudentId = (id: string) => {
    const regex = /^DH([1-9]|[1-7][0-9]|80)$/;
    return regex.test(id.trim().toUpperCase());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!name.trim() || name.trim().split(' ').length < 2) {
      setError('Fadlan geli magacaaga oo saddexan (Full Name).');
      return;
    }
    
    const upperId = studentId.trim().toUpperCase();
    if (!validateStudentId(upperId)) {
      setError('Fadlan geli ID sax ah (tusaale: DH01 - DH80).');
      return;
    }

    if (activeTab === 'private') {
      const savedCode = localStorage.getItem('quiz_access_code') || '1234';
      if (quizCode.trim() !== savedCode) {
        setError('Quiz Code-ka aad gelisay waa khalad. La xiriir macalinkaaga.');
        return;
      }
    }
    
    // Pass the category the student selected (activeTab) to filter questions accordingly
    onStart({ name, studentId: upperId }, activeTab);
  };

  const minutes = Math.floor(timeLimit / 60);

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-[3.5rem] shadow-2xl shadow-slate-200/50 overflow-hidden border border-slate-100 transition-all">
        {/* Header Section */}
        <div className="bg-gradient-to-br from-blue-700 to-indigo-800 p-12 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
          <div className="relative z-10 text-center">
            <div className="inline-block px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-full text-[10px] font-black uppercase tracking-[0.3em] mb-6">
              ALNACIIM DEGITAL EDUCATION
            </div>
            <h2 className="text-5xl font-black leading-none tracking-tighter mb-4">DHABAC QUIZ</h2>
            <p className="text-blue-100/80 font-medium text-sm">Geli aqoonsigaaga si aad u bilowdo imtixaanka.</p>
          </div>
        </div>
        
        {/* Navigation Tabs */}
        <div className="flex p-2 bg-slate-50 mx-10 mt-8 rounded-2xl gap-2 border border-slate-100">
          <button 
            onClick={() => { setActiveTab('general'); setError(''); }}
            className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeTab === 'general' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
            </svg>
            Imtixaan Guud (ID bis)
          </button>
          <button 
            onClick={() => { setActiveTab('private'); setError(''); }}
            className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${activeTab === 'private' ? 'bg-white text-blue-600 shadow-lg' : 'text-slate-400 hover:text-slate-600'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            Imtixaan Gaar ah (Code)
          </button>
        </div>

        <div className="p-10">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="group">
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Magacaaga oo Buuxa</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Eidle Maxamed Abdulaahi Ali"
                  className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 focus:bg-white transition-all outline-none font-bold text-slate-700"
                />
              </div>
              <div className="group">
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">ID-ga Ardayga</label>
                <input 
                  type="text" 
                  value={studentId}
                  onChange={(e) => setStudentId(e.target.value)}
                  placeholder="DH..."
                  className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-blue-100 focus:border-blue-500 focus:bg-white transition-all outline-none font-bold text-slate-700"
                />
              </div>
            </div>

            {activeTab === 'private' && (
              <div className="group animate-in slide-in-from-top-4 duration-300">
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2 ml-1 text-center">Quiz Code (Geli Fure)</label>
                <div className="relative">
                  <input 
                    type="password" 
                    value={quizCode}
                    onChange={(e) => setQuizCode(e.target.value)}
                    placeholder="****"
                    className="w-full px-6 py-5 bg-blue-50 border border-blue-100 rounded-3xl focus:ring-4 focus:ring-blue-200 focus:border-blue-500 focus:bg-white transition-all outline-none font-black text-center text-3xl tracking-[0.5em] text-blue-900"
                  />
                </div>
              </div>
            )}
            
            {error && (
              <div className="p-4 bg-red-50 rounded-2xl border border-red-100 flex items-center gap-3 text-red-600 text-xs font-bold animate-shake">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {error}
              </div>
            )}

            <button 
              type="submit"
              className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-xl hover:bg-slate-800 shadow-2xl transition-all transform hover:-translate-y-1 active:scale-95"
            >
              {activeTab === 'general' ? 'BILOW IMTIXAAN GUUD' : 'BILOW IMTIXAAN GAAR AH'}
            </button>
          </form>

          <div className="mt-10 flex justify-center gap-10 text-slate-400">
             <div className="flex flex-col items-center">
                <span className="font-black text-slate-900 text-lg leading-none">
                   {questionsCount}
                </span>
                <span className="text-[9px] font-black uppercase tracking-widest mt-1">Su'aalo Wadajir</span>
             </div>
             <div className="w-px h-8 bg-slate-100 self-center"></div>
             <div className="flex flex-col items-center">
                <span className="font-black text-slate-900 text-lg leading-none">{minutes}</span>
                <span className="text-[9px] font-black uppercase tracking-widest mt-1">Daqiiqo</span>
             </div>
          </div>
        </div>
      </div>
      
      <p className="text-center mt-8 text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">
        DHABAC QUIZ - SMART EDUCATION SYSTEM
      </p>
    </div>
  );
};

export default Dashboard;
