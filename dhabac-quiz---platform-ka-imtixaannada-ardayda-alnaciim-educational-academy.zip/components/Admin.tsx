
import React, { useState, useEffect } from 'react';
import { Question, QuestionType, MediaType, QuizCategory, QuizResult, ManagerAdmin } from '../types';

interface AdminProps {
  questions: Question[];
  onUpdateQuestions: (questions: Question[]) => void;
  onCategoryChange: (category: QuizCategory) => void;
  currentCategory: QuizCategory;
  onBack: () => void;
}

const Admin: React.FC<AdminProps> = ({ questions, onUpdateQuestions, onCategoryChange, currentCategory, onBack }) => {
  const [activeTab, setActiveTab] = useState<'questions' | 'submissions' | 'managers'>('questions');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [quizCode, setQuizCode] = useState(() => localStorage.getItem('quiz_access_code') || '1234');
  const [teacherEmail] = useState(() => localStorage.getItem('teacher_gmail') || 'edmoupdy@gmail.com');
  const [showCode, setShowCode] = useState(false);
  const [submissions, setSubmissions] = useState<QuizResult[]>([]);
  const [managers, setManagers] = useState<ManagerAdmin[]>(() => {
    const saved = localStorage.getItem('manager_admins');
    return saved ? JSON.parse(saved) : [];
  });
  
  // Manager Form State
  const [newManagerEmail, setNewManagerEmail] = useState('');
  const [newManagerPass, setNewManagerPass] = useState('');

  const MAIN_ADMIN_EMAIL = 'edmoupdy@gmail.com';
  const isMainAdmin = teacherEmail.toLowerCase() === MAIN_ADMIN_EMAIL;

  const [newQuestion, setNewQuestion] = useState<Partial<Question>>({
    type: 'multiple-choice',
    options: ['', '', '', ''],
    text: '',
    correctAnswer: '',
    mediaType: 'none',
    mediaUrl: '',
    category: 'general'
  });

  useEffect(() => {
    localStorage.setItem('quiz_access_code', quizCode);
  }, [quizCode]);

  useEffect(() => {
    localStorage.setItem('manager_admins', JSON.stringify(managers));
  }, [managers]);

  useEffect(() => {
    const savedSubmissions = localStorage.getItem('quiz_submissions');
    if (savedSubmissions) {
      setSubmissions(JSON.parse(savedSubmissions));
    }
  }, []);

  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuestion.text || !newQuestion.correctAnswer) return;

    if (editingId) {
      const updatedQuestions = questions.map(q => 
        q.id === editingId ? { ...q, ...newQuestion } as Question : q
      );
      onUpdateQuestions(updatedQuestions);
      setEditingId(null);
    } else {
      if (questions.length >= 100) {
        alert("Nidaamku ma oggola wax ka badan 100 su'aalood hal mar.");
        return;
      }
      const q: Question = {
        id: Date.now().toString(),
        text: newQuestion.text as string,
        type: newQuestion.type as QuestionType,
        options: newQuestion.type === 'multiple-choice' ? newQuestion.options : undefined,
        correctAnswer: newQuestion.correctAnswer as string,
        mediaType: newQuestion.mediaType as MediaType,
        mediaUrl: newQuestion.mediaUrl,
        category: newQuestion.category as QuizCategory
      };
      onUpdateQuestions([...questions, q]);
    }
    setNewQuestion({ 
      type: 'multiple-choice', 
      options: ['', '', '', ''], 
      text: '', 
      correctAnswer: '', 
      mediaType: 'none', 
      mediaUrl: '', 
      category: newQuestion.category 
    });
  };

  const handleAddManager = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newManagerEmail.trim() || !newManagerPass.trim()) return;
    
    if (managers.some(m => m.email.toLowerCase() === newManagerEmail.toLowerCase().trim())) {
      alert("Maamulahani mar hore ayuu diiwaangashan yahay.");
      return;
    }

    const m: ManagerAdmin = {
      id: Date.now().toString(),
      email: newManagerEmail.toLowerCase().trim(),
      password: newManagerPass,
      role: 'manager'
    };
    setManagers([...managers, m]);
    setNewManagerEmail('');
    setNewManagerPass('');
  };

  const startEdit = (q: Question) => {
    setEditingId(q.id);
    setNewQuestion({ ...q });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const exportAllCSV = () => {
    if (submissions.length === 0) return;
    const headers = ['Ardayga', 'ID', 'Category', 'Dhibcaha', 'Sax', 'Qalad', 'Boqolayda', 'Waqtiga', 'Farriinta'];
    const rows = submissions.map(res => [
      `"${res.user.name}"`, res.user.studentId, res.category, res.totalQuestions, res.correctAnswers, res.wrongAnswers, `${res.percentage.toFixed(1)}%`, new Date(res.timestamp).toLocaleString(), `"${(res.studentMessage || '').replace(/"/g, '""')}"`
    ]);
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + headers.join(",") + "\n" + rows.map(e => e.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Dhabac_Quiz_Results_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clearSubmissions = () => {
    if (window.confirm('Ma hubtaa inaad tirtirto dhammaan natiijooyinka ardayda?')) {
      localStorage.removeItem('quiz_submissions');
      setSubmissions([]);
    }
  };

  const clearAllQuestions = () => {
    if (window.confirm('Ma hubtaa inaad tirtirto DHAMMAAN su\'aalaha (Guud & Gaar ah)?')) {
      onUpdateQuestions([]);
    }
  };

  const privateQuestions = questions.filter(q => q.category === 'private');
  const generalQuestions = questions.filter(q => q.category === 'general');

  return (
    <div className="max-w-7xl mx-auto space-y-10 pb-32">
      {/* Dynamic Header */}
      <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl shadow-indigo-100 border border-slate-50 flex flex-col md:flex-row items-center justify-between gap-10">
        <div className="flex items-center gap-6">
          <div className="w-20 h-20 bg-slate-900 rounded-[2rem] flex items-center justify-center text-white shadow-2xl ring-8 ring-indigo-50">
            {isMainAdmin ? (
               <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
               </svg>
            ) : (
               <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
               </svg>
            )}
          </div>
          <div>
            <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase leading-none mb-1">
              {isMainAdmin ? 'Main Admin' : 'Manager Panel'}
            </h2>
            <div className="flex items-center gap-2">
               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
               <p className="text-slate-400 text-xs font-black uppercase tracking-widest">{teacherEmail}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-4">
          <div className="bg-slate-100 p-2 rounded-[2rem] flex shadow-inner border border-slate-200">
            <button 
              onClick={() => setActiveTab('questions')}
              className={`px-10 py-4 rounded-[1.5rem] font-black text-[11px] uppercase tracking-widest transition-all ${activeTab === 'questions' ? 'bg-white text-indigo-600 shadow-xl' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Su'aalaha
            </button>
            <button 
              onClick={() => setActiveTab('submissions')}
              className={`px-10 py-4 rounded-[1.5rem] font-black text-[11px] uppercase tracking-widest transition-all ${activeTab === 'submissions' ? 'bg-white text-indigo-600 shadow-xl' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Natiijooyinka
            </button>
            {isMainAdmin && (
               <button 
                onClick={() => setActiveTab('managers')}
                className={`px-10 py-4 rounded-[1.5rem] font-black text-[11px] uppercase tracking-widest transition-all ${activeTab === 'managers' ? 'bg-white text-indigo-600 shadow-xl' : 'text-slate-400 hover:text-slate-600'}`}
              >
                Maamulayaasha
              </button>
            )}
          </div>
          <button 
            onClick={onBack}
            className="px-10 py-5 bg-slate-900 text-white rounded-[2rem] font-black text-[11px] uppercase tracking-widest hover:bg-slate-800 transition shadow-xl active:scale-95"
          >
            Ka bax
          </button>
        </div>
      </div>

      {activeTab === 'questions' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start animate-in fade-in duration-500">
          {/* Settings & Add Area */}
          <div className="lg:col-span-5 space-y-10 lg:sticky lg:top-24">
            <div className="bg-indigo-600 p-10 rounded-[3.5rem] shadow-2xl text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full -mr-20 -mt-20 blur-3xl"></div>
              <h3 className="text-[10px] font-black text-indigo-200 uppercase tracking-[0.4em] mb-10 flex items-center gap-3">
                <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
                HABAYNTA IMTIXAANKA
              </h3>
              
              <div className="space-y-8 relative z-10">
                <div className="space-y-4">
                  <label className="block text-[9px] font-black text-indigo-200 uppercase tracking-widest ml-1">Dooro Nooca (Active Mode)</label>
                  <div className="grid grid-cols-2 gap-2 bg-indigo-700/50 p-2 rounded-[1.8rem] border border-white/10">
                    <button onClick={() => onCategoryChange('general')} className={`py-4 rounded-[1.3rem] text-[10px] font-black uppercase tracking-widest transition-all ${currentCategory === 'general' ? 'bg-white text-indigo-600 shadow-xl' : 'text-indigo-300 hover:text-white'}`}>Guud</button>
                    <button onClick={() => onCategoryChange('private')} className={`py-4 rounded-[1.3rem] text-[10px] font-black uppercase tracking-widest transition-all ${currentCategory === 'private' ? 'bg-white text-indigo-600 shadow-xl' : 'text-indigo-300 hover:text-white'}`}>Gaar ah</button>
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-white/10">
                  <label className="block text-[9px] font-black text-indigo-200 uppercase tracking-widest ml-1">Access Code</label>
                  <div className="relative">
                    <input type={showCode ? 'text' : 'password'} value={quizCode} onChange={(e) => setQuizCode(e.target.value)} className="w-full bg-white/10 border border-white/20 rounded-[1.8rem] p-6 text-center font-black text-3xl tracking-[0.5em] text-white outline-none focus:bg-white/20 transition-all" />
                    <button type="button" onClick={() => setShowCode(!showCode)} className="absolute right-5 top-1/2 -translate-y-1/2 p-2 text-white/50 hover:text-white"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg></button>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl border border-slate-100">
              <h3 className="text-2xl font-black text-slate-800 tracking-tighter uppercase mb-10">{editingId ? 'Wax ka Beddel' : 'Ku dar Su\'aal'}</h3>
              <form onSubmit={handleSaveQuestion} className="space-y-8">
                <div className="grid grid-cols-2 gap-4">
                  <select className="p-5 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-sm outline-none" value={newQuestion.type} onChange={(e) => setNewQuestion({...newQuestion, type: e.target.value as QuestionType})}>
                    <option value="multiple-choice">Xulasho (A,B,C,D)</option>
                    <option value="true-false">Run/Been</option>
                  </select>
                  <select className="p-5 bg-indigo-50 border border-indigo-100 rounded-2xl font-black text-sm text-indigo-700 outline-none" value={newQuestion.category} onChange={(e) => setNewQuestion({...newQuestion, category: e.target.value as QuizCategory})}>
                    <option value="general">Guud</option>
                    <option value="private">Gaar ah</option>
                  </select>
                </div>
                <textarea className="w-full p-6 bg-slate-50 border border-slate-200 rounded-[2rem] font-bold text-sm outline-none focus:ring-4 focus:ring-indigo-50 min-h-[120px]" value={newQuestion.text} onChange={(e) => setNewQuestion({...newQuestion, text: e.target.value})} placeholder="Qor su'aasha halkan..." />
                {newQuestion.type === 'multiple-choice' && (
                  <div className="grid grid-cols-2 gap-4">
                    {newQuestion.options?.map((opt, i) => (
                      <input key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={opt} onChange={(e) => { const opts = [...(newQuestion.options || [])]; opts[i] = e.target.value; setNewQuestion({...newQuestion, options: opts}); }} placeholder={`Opt ${String.fromCharCode(65+i)}`} />
                    ))}
                  </div>
                )}
                <input className="w-full p-5 bg-green-50 border border-green-200 rounded-2xl font-black text-green-700 text-sm outline-none" placeholder="Jawaabta Saxda ah" value={newQuestion.correctAnswer} onChange={(e) => setNewQuestion({...newQuestion, correctAnswer: e.target.value})} />
                <button type="submit" className="w-full py-6 bg-indigo-600 text-white rounded-[2rem] font-black text-sm uppercase shadow-2xl hover:bg-indigo-700 transition active:scale-95">{editingId ? 'Cusboonaysii' : 'Kaydi Su\'aasha'}</button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-12">
            <div className="flex justify-between items-center px-4">
               <div><h3 className="text-2xl font-black text-slate-900 tracking-tighter uppercase">Xogta Su'aalaha</h3><p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mt-1">Pool: {questions.length} / 100</p></div>
               <button onClick={clearAllQuestions} className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:bg-red-50 px-6 py-3 rounded-2xl border border-red-100 transition-all">Clear All</button>
            </div>
            <div className="space-y-4">
               {questions.map((q, i) => <AdminQuestionCard key={q.id} q={q} idx={i} onEdit={startEdit} onDelete={() => onUpdateQuestions(questions.filter(x => x.id !== q.id))} color={q.category === 'private' ? 'indigo' : 'slate'} />)}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'submissions' && (
        <div className="space-y-10 animate-in slide-in-from-right duration-500">
           <div className="bg-white p-10 rounded-[3.5rem] border border-slate-100 shadow-2xl flex flex-col md:flex-row justify-between items-center gap-8">
             <div><h3 className="text-3xl font-black text-slate-800 tracking-tighter uppercase leading-none">Submissions Hub</h3><p className="text-slate-400 text-xs font-black uppercase tracking-widest mt-2">Kormeerka natiijooyinka ardayda ({submissions.length})</p></div>
             <div className="flex gap-4">
                <button onClick={clearSubmissions} className="px-8 py-4 bg-red-50 text-red-500 rounded-2xl font-black text-[11px] uppercase tracking-widest border border-red-100 hover:bg-red-100">Clear Submissions</button>
                <button onClick={exportAllCSV} disabled={submissions.length === 0} className="px-10 py-5 bg-green-600 text-white rounded-[1.8rem] font-black text-[11px] uppercase tracking-widest shadow-2xl shadow-green-100 hover:bg-green-700 disabled:opacity-30">Export CSV (Bulk)</button>
             </div>
           </div>
           <div className="bg-white rounded-[3.5rem] shadow-2xl border border-slate-100 overflow-hidden overflow-x-auto">
             <table className="w-full text-left min-w-[800px]">
               <thead><tr className="bg-slate-50 border-b border-slate-100"><th className="p-10 text-[11px] font-black uppercase text-slate-400 tracking-widest">Student & ID</th><th className="p-10 text-[11px] font-black uppercase text-slate-400 tracking-widest">Mode</th><th className="p-10 text-[11px] font-black uppercase text-slate-400 tracking-widest text-center">Score</th><th className="p-10 text-[11px] font-black uppercase text-slate-400 tracking-widest">Time</th><th className="p-10 text-[11px] font-black uppercase text-slate-400 tracking-widest">Note</th></tr></thead>
               <tbody className="divide-y divide-slate-100">
                 {submissions.length === 0 ? <tr><td colSpan={5} className="p-40 text-center text-slate-300 font-black uppercase text-xs tracking-[0.5em]">Hadda ma jiraan natiijooyin.</td></tr> : submissions.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((res, i) => (
                   <tr key={i} className="group hover:bg-slate-50/50 transition-all"><td className="p-10"><div className="flex items-center gap-5"><div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 font-black text-sm shadow-inner group-hover:scale-110 transition-transform">{res.user.studentId.replace('DH', '')}</div><div><p className="font-black text-slate-800 text-xl leading-none mb-1 group-hover:text-indigo-600">{res.user.name}</p><p className="text-[10px] font-black text-slate-400 tracking-widest uppercase">{res.user.studentId}</p></div></div></td><td className="p-10"><span className={`px-5 py-2 rounded-2xl text-[10px] font-black uppercase border ${res.category === 'general' ? 'bg-slate-100 border-slate-200' : 'bg-indigo-600 text-white'}`}>{res.category}</span></td><td className="p-10 text-center"><span className={`text-4xl font-black ${res.percentage >= 70 ? 'text-green-600' : 'text-red-600'}`}>{Math.round(res.percentage)}%</span></td><td className="p-10"><p className="text-sm font-black text-slate-700 mb-1">{new Date(res.timestamp).toLocaleDateString()}</p><p className="text-[10px] font-bold text-slate-400 uppercase">{new Date(res.timestamp).toLocaleTimeString()}</p></td><td className="p-10 max-w-[300px]">{res.studentMessage ? <div className="p-5 bg-blue-50 rounded-2xl border border-blue-100 italic text-xs font-bold text-slate-600">"{res.studentMessage}"</div> : <span className="text-slate-100">No message</span>}</td></tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      )}

      {activeTab === 'managers' && isMainAdmin && (
        <div className="space-y-10 animate-in slide-in-from-right duration-500">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Form Column */}
            <div className="lg:col-span-5 space-y-10">
              <div className="bg-white p-10 rounded-[3.5rem] shadow-2xl border border-slate-100">
                <h3 className="text-2xl font-black text-slate-800 tracking-tighter uppercase mb-10 flex items-center gap-4">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg></div>
                  Manager Cusub
                </h3>
                <form onSubmit={handleAddManager} className="space-y-6">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Manager Gmail</label>
                    <input type="email" value={newManagerEmail} onChange={(e) => setNewManagerEmail(e.target.value)} placeholder="tusaale@gmail.com" className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-100 outline-none font-bold" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Manager Password</label>
                    <input type="password" value={newManagerPass} onChange={(e) => setNewManagerPass(e.target.value)} placeholder="••••••••" className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-4 focus:ring-indigo-100 outline-none font-bold" />
                  </div>
                  <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-sm uppercase shadow-2xl hover:bg-indigo-700 transition active:scale-95">Diiwaangali Manager</button>
                </form>
              </div>
            </div>

            {/* List Column */}
            <div className="lg:col-span-7 space-y-6">
              <div className="bg-indigo-900 p-8 rounded-[3rem] text-white">
                <h3 className="text-xl font-black uppercase tracking-widest mb-4">Liiska Maamulayaasha</h3>
                <div className="space-y-4">
                  {/* Hardcoded Main Admin */}
                  <div className="bg-white/10 p-6 rounded-2xl flex justify-between items-center border border-white/10">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-indigo-500 rounded-xl flex items-center justify-center text-white font-black">M</div>
                      <div>
                        <p className="font-black text-white">{MAIN_ADMIN_EMAIL}</p>
                        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">System Master Admin</p>
                      </div>
                    </div>
                    <span className="px-4 py-1.5 bg-indigo-500/20 text-indigo-400 text-[10px] font-black rounded-lg uppercase tracking-widest border border-indigo-500/30">Loo Ma Taaban Karo</span>
                  </div>

                  {managers.length === 0 ? (
                    <div className="p-12 text-center border-2 border-dashed border-white/10 rounded-2xl text-indigo-300 font-bold">Ma jiraan maamulayaal dheeraad ah.</div>
                  ) : managers.map((m) => (
                    <div key={m.id} className="bg-white p-6 rounded-2xl flex justify-between items-center border border-slate-100 shadow-xl animate-in slide-in-from-bottom-2 duration-300">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 font-black">A</div>
                        <div>
                          <p className="font-black text-slate-800">{m.email}</p>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Manager Account</p>
                        </div>
                      </div>
                      <button onClick={() => setManagers(managers.filter(x => x.id !== m.id))} className="p-3 bg-red-50 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all shadow-sm">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const AdminQuestionCard = ({ q, idx, onEdit, onDelete, color }: { q: Question, idx: number, onEdit: (q: Question) => void, onDelete: () => void, color: 'indigo' | 'slate' }) => (
  <div className={`bg-white p-10 rounded-[3.5rem] shadow-xl border border-slate-100 flex items-start gap-8 group hover:border-${color}-200 hover:shadow-2xl transition-all duration-500 animate-in slide-in-from-bottom-2`}>
    <div className={`w-16 h-16 rounded-[1.8rem] bg-slate-50 text-slate-300 flex items-center justify-center font-black text-2xl group-hover:bg-${color === 'indigo' ? 'indigo-600' : 'slate-900'} group-hover:text-white transition-all duration-500 shadow-inner shrink-0`}>
      {idx + 1}
    </div>
    <div className="flex-1 min-w-0">
      <div className="flex items-center gap-3 mb-4"><span className={`px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border ${color === 'indigo' ? 'bg-indigo-50 text-indigo-600 border-indigo-100' : 'bg-slate-50 text-slate-400 border-slate-100'}`}>{q.type}</span></div>
      <h5 className="font-black text-slate-800 text-2xl mb-8 leading-[1.2] tracking-tight group-hover:text-slate-900">{q.text}</h5>
      {q.type === 'multiple-choice' && q.options && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
           {q.options.map((opt, i) => (
             <div key={i} className={`p-5 rounded-[1.5rem] border-2 text-[12px] font-bold flex items-center gap-4 ${opt === q.correctAnswer ? 'border-green-200 bg-green-50 text-green-700' : 'border-slate-50 bg-slate-50 text-slate-400'}`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs ${opt === q.correctAnswer ? 'bg-green-600 text-white shadow-lg' : 'bg-white text-slate-300'}`}>{String.fromCharCode(65+i)}</div>
                {opt}
             </div>
           ))}
        </div>
      )}
      <div className="flex items-center gap-2 pt-6 border-t border-slate-50"><span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Jawaabta Saxda ah:</span><span className="text-sm font-black text-green-600 uppercase tracking-wider">{q.correctAnswer}</span></div>
    </div>
    <div className="flex flex-col gap-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-4 group-hover:translate-x-0 shrink-0">
      <button onClick={() => onEdit(q)} className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-[1.3rem] hover:bg-indigo-600 hover:text-white transition-all shadow-xl shadow-indigo-100 border border-indigo-100 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg></button>
      <button onClick={onDelete} className="w-14 h-14 bg-red-50 text-red-500 rounded-[1.3rem] hover:bg-red-600 hover:text-white transition-all shadow-xl shadow-red-100 border border-red-100 flex items-center justify-center"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
    </div>
  </div>
);

const NoContent = ({ message }: { message: string }) => (
  <div className="p-20 bg-white rounded-[3.5rem] border-4 border-dashed border-slate-50 text-center"><p className="text-slate-300 font-black uppercase text-xs tracking-[0.4em]">{message}</p></div>
);

export default Admin;
