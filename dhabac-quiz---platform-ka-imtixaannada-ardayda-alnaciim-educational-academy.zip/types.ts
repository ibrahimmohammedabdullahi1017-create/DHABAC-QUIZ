
export type QuestionType = 'multiple-choice' | 'true-false';
export type MediaType = 'none' | 'image' | 'video';
export type QuizCategory = 'general' | 'private';

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  correctAnswer: string;
  mediaType?: MediaType;
  mediaUrl?: string;
  category: QuizCategory;
}

export interface User {
  name: string;
  studentId: string;
  gmail?: string;
}

export interface ManagerAdmin {
  id: string;
  email: string;
  password: string;
  role: 'manager';
}

export interface QuizResult {
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  percentage: number;
  timestamp: string;
  user: User;
  userAnswers: Record<string, string>;
  questions: Question[];
  studentMessage?: string;
  category: QuizCategory;
}

export enum AppState {
  LANDING = 'LANDING',
  IDLE = 'IDLE',
  TAKING = 'TAKING',
  COMPLETED = 'COMPLETED',
  ADMIN_AUTH = 'ADMIN_AUTH',
  ADMIN = 'ADMIN'
}
