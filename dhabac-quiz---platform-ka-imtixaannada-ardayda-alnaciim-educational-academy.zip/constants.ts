
import { Question } from './types';

export const INITIAL_QUESTIONS: Question[] = [
  {
    id: 'g1',
    text: 'Waa maxay caasimadda dalka Soomaaliya?',
    type: 'multiple-choice',
    options: ['Hargeysa', 'Muqdisho', 'Garowe', 'Kismaayo'],
    correctAnswer: 'Muqdisho',
    category: 'general'
  },
  {
    id: 'g2',
    text: 'Biyuhu waxay karkaraan marka heerkulku gaaro 100°C.',
    type: 'true-false',
    correctAnswer: 'Run',
    category: 'general'
  },
  {
    id: 'p1',
    text: 'Imisa xubnood ayuu ka kooban yahay jirka bini-aadamka marka laga hadlayo neerfaha?',
    type: 'multiple-choice',
    options: ['Malaayiin', 'Bilyan', 'Kumanyaal', 'Ma la xisaabin karo'],
    correctAnswer: 'Bilyan',
    category: 'private'
  },
  {
    id: 'p2',
    text: 'Webiga Jubba waa webiga ugu dheer Soomaaliya.',
    type: 'true-false',
    correctAnswer: 'Been',
    category: 'private'
  }
];

export const QUIZ_CONFIG = {
  title: "DHABAC QUIZ SYSTEM",
  timeLimitSeconds: 600, // 10 minutes
  passingGrade: 70,
};
